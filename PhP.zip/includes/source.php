<?php 
    echo ("<p><a ");
    echo ("href=\"src/".$_GET['page'].".phps\">");
    echo ("Ver código fuente</a></p>")
?>