<div id="templatemo_bottom_wrapper">
<div id="templatemo_footer_wrapper">    
    <div id="templatemo_footer">
    	<p>Christopher Muñoz Godenir&nbsp;&nbsp;&nbsp;&nbsp;
    	<a href="http://www.alpha-developer.blogspot.com.es">alpha-developer.blogspot.com.es</a>
    	 <!-- Credit: www.templatemo.com --></p>
    </div><!-- END of templatemo_footer -->
</div><!-- END of templatemo_footer_wrapper -->
</body>
</html>