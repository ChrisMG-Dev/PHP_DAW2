<?php include("includes/top_page.php"); ?>
<?php include("includes/header.php"); ?>       
<?php include("includes/menu.php"); ?>
<?php 
	ob_start(); 
	echo("<div id=\"templatemo_main\">"); 
?>
      <?php include("includes/pages.php"); ?>             
<?php 
	echo("</div>"); 
	ob_end_flush();
?>
<?php include("includes/footer.php"); ?>