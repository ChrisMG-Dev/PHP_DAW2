<div id="templatemo_menu" class="ddsmoothmenu">
        <ul>
            <li><a href="?page=principal" class="selected">Inicio</a></li>
            <li><a href="#">Actividades</a>
                <ul>
                    <li><a rel="nofollow" href="?page=ejercicio1">
                            Ficha Personal</a></li>
                    <li><a rel="nofollow" href="?page=mayordedos">
                            Mayor de dos números</a></li>
                    <li><a rel="nofollow" href="?page=fechanacimiento">
                            Fecha de nacimiento</a></li>
                    <li><a rel="nofollow" href="?page=paletacolores">
                            Paleta de colores</a></li>
                    <li><a rel="nofollow" href="?page=diasdelmes">
                            Días del mes</a></li>
                    <li><a rel="nofollow" href="?page=estaciones">
                            Estaciones</a></li>
                    <li><a rel="nofollow" href="?page=calendario">
                            Calendario</a></li>
                    <li><a rel="nofollow" href="?page=alumnoscursos">
                            Cursos Alumnos</a></li>
                    <li><a rel="nofollow" href="?page=notasdwes">
                            Notas</a></li>
                    <li><a rel="nofollow" href="?page=formulario">
                            Formulario (EJ clase)</a></li>
              	</ul>
            </li>
            <li><a href="#">Arrays</a>
                <ul>
                    <li><a rel="nofollow" href="?page=ventas_diarias">
                            Ventas</a></li>
                    <li><a rel="nofollow" href="?page=enteros">
                            Números enteros</a></li>
                    <li><a rel="nofollow" href="?page=primitiva">
                            Primitiva</a></li>
                    <li><a rel="nofollow" href="?page=arrays">
                            Usuarios y multas </a></li>
                
              	</ul>
            </li>
            <li><a href="#">Formularios</a>
                <ul>
                    <li><a rel="nofollow" href="?page=formulario_mesanio">
                            Mes y Año</a></li>
                    <li><a rel="nofollow" href="?page=formulario_cv">
                            Curriculum</a></li>
                    <li><a rel="nofollow" href="?page=formulario_paises">
                            Banderas</a></li>
                    <li><a rel="nofollow" href="?page=formulario_suma">
                            Sumar números</a></li>
              	</ul>
            </li>
            <li><a href="#">Cookies</a>
                <ul>
                    <li><a rel="nofollow" href="?page=login">
                            Login</a></li>
                </ul>
            </li>
            <li><a href="http://alpha-developer.blogspot.com.es">Blog</a></li>
        </ul>
    <br style="clear: left" />
</div>