<?php ob_start(); ?>
<?php include("includes/top_page.php"); ?>
<?php include("includes/header.php"); ?>       
<?php include("includes/menu.php"); ?>
<?php 
	echo("<div id=\"templatemo_main\">"); 
?>
<?php include("includes/pages.php"); ?>             
<?php 
	echo("</div>"); 
?>
<?php include("includes/footer.php"); ?>
<?php 
	$file_content = ob_get_contents();
	ob_end_clean ();
	echo $file_content;
?>